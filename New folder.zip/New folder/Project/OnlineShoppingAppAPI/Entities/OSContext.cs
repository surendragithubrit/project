﻿using Microsoft.EntityFrameworkCore;

namespace OnlineShoppingAppAPI.Entities
{
    public class OSContext:DbContext
    {
        private IConfiguration _configuration;

        public OSContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        //Entity Set
        public DbSet<User>Users { get; set; }
        //Configure Connectionstring
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("OSConnection"));
        }
    }
}
