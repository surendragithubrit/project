﻿using OnlineShoppingAppAPI.Entities;

namespace OnlineShoppingAppAPI.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly OSContext _context;
        private IConfiguration _configuration;

        public UserRepository(OSContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public void Register(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public User ValidUser(string email, string password)
        {
            return _context.Users.SingleOrDefault(a=>a.Email==email&& a.Password==password);    
        }
    }
}
